library(testthat)
library(mice.pcr.sim)

test_check("mice.pcr.sim")
