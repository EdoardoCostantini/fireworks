#' MNAR demo data
#'
#' A toy example from Margarita Moreno-Betancur for checking NARFCS.
#'
#' A small dataset with just three columns.
#' @source \url{https://github.com/moreno-betancur/NARFCS/blob/master/datmis.csv}
"mnar_demo_data"
